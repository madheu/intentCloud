"""IntCog-R core package."""
